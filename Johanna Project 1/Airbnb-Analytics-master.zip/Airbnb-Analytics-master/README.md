# Airbnb-Analytics
Team Members:
Holly
Johanna
Patrick
Rose

Project Title: AIRBNB CITIES

Description: Analyze Airbnb data in four different cities 

Data source: http://tomslee.net/airbnb-data-collection-get-the-data

3-5 Initial  Research Questions:
 
• Is there any correlation between price and rating?

• Which cities are the most/least expensive?

• Is there any correlation between minimum stay and price?

• Is there a preferred room type (private room, entire house)?
